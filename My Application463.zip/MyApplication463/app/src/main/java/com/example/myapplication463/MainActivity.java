package com.example.myapplication463;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.core.Repo;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.*;
import retrofit2.http.Path;

public class MainActivity extends AppCompatActivity {
    private TextView t1;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private int a=0;
    private int b=0;
    private int c=0;
    private int d=0;
    private int e=0;

    private double temp=0;
    private int humi=0;
    private int waterLevel=0;
    private int CO2=0;

    private Button btn1;
    private Button btn2;
    private Button btn3;
    private Button btn4;
    private Button btn5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1 = findViewById(R.id.textView);
        btn1=(Button)findViewById(R.id.button);
        btn2=(Button)findViewById(R.id.button2);
        btn3=(Button)findViewById(R.id.button3);
        btn4=(Button)findViewById(R.id.button4);
        btn5=(Button)findViewById(R.id.button5);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while(!Thread.interrupted()){
                    try{

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                getPosts();
                            }
                        });
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();



        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(a==1) {
                    a=0;
                    btn1.setText("autoMode:0");
                    btn2.setClickable(true);btn3.setClickable(true);
                    btn4.setClickable(true);btn5.setClickable(true);
                }
                else{
                    a=1;
                    btn1.setText("autoMode:1");
                    b=0;c=0;d=0;e=0;
                    btn2.setClickable(false);btn3.setClickable(false);
                    btn4.setClickable(false);btn5.setClickable(false);
                }
                createPost(a, b, c, d,e);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b==1) {
                    b=0;
                    btn2.setText("RELAY1:0");
                }
                else{
                    b=1;
                    btn2.setText("RELAY1:1");
                }
                createPost(a, b, c, d,e);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(c==1) {
                    c=0;
                    btn3.setText("RELAY2:0");
                }
                else{
                    c=1;
                    btn3.setText("RELAY2:1");
                }
                createPost(a, b, c, d,e);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(d==1) {
                    d=0;
                    btn4.setText("RELAY3:0");
                }
                else{
                    d=1;
                    btn4.setText("RELAY3:1");
                }
                createPost(a, b, c, d,e);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(e==1) {
                    e=0;
                    btn5.setText("RELAY4:0");
                }
                else{
                    e=1;
                    btn5.setText("RELAY4:1");
                }
                createPost(a, b, c, d,e);
            }
        });


        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://ziot.i4624.cf/").
                addConverterFactory(GsonConverterFactory.create()).build();

        jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);

    }

    //1강 GET
    private void getPosts(){
        Call<List<Post>> call = jsonPlaceHolderApi.getPosts();

        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if (!response.isSuccessful()) {
                    t1.setText("Code : " + response.code());
                    return;
                }
                List<Post> gets = response.body();
                for (Post get : gets) {
                    String content = "";
                    content += "온도 : " + get.getTemperature() + "\n";
                    content += "습도 : " + get.getHumi() + "\n";
                    content += "CO2 : " + get.getCo2() + "\n";
                    content += "수위 : " + get.getWaterLevel() + "\n";


                    content += "auto : "+ get.getAutoMode()+"\n";
                    content += "relay1 : "+ get.getRelay1()+"\n";
                    content += "relay2 : "+ get.getRelay2()+"\n";
                    content += "relay3 : "+ get.getRelay3()+"\n";
                    content += "relay4 : "+ get.getRelay4()+"\n";

                    a=get.getAutoMode();
                    b=get.getRelay1();
                    c=get.getRelay2();
                    d=get.getRelay3();
                    e=get.getRelay4();
                    if(a==1) {
                        btn1.setText("AUTOMODE:1");
                        btn2.setClickable(false);btn3.setClickable(false);
                        btn4.setClickable(false);btn5.setClickable(false);
                    }
                    else {
                        btn1.setText("AUTOMODE:0");
                        btn2.setClickable(true);btn3.setClickable(true);
                        btn4.setClickable(true);btn5.setClickable(true);
                    }
                    if(b==1)
                        btn2.setText("RELAY1:1");
                    else
                        btn2.setText("RELAY1:0");
                    if(c==1)
                        btn3.setText("RELAY2:1");
                    else
                        btn3.setText("RELAY2:0");
                    if(d==1)
                        btn4.setText("RELAY3:1");
                    else
                        btn4.setText("RELAY3:0");
                    if(e==1)
                        btn5.setText("RELAY4:1");
                    else
                        btn5.setText("RELAY4:0");

                    temp=get.getTemperature();
                    humi=get.getHumi();
                    CO2=get.getCo2();
                    waterLevel=get.getWaterLevel();

                    t1.setText(content);

                }
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                t1.setText(t.getMessage());
            }
        });
    }

    private void createPost(int a,int b,int c,int d, int e){ //a=autoMode,b~e =relay1~4
        Post post=new Post(CO2,temp,humi,waterLevel,a,b,c,d,e);

        Call<Post> call=jsonPlaceHolderApi.createPost(post);

        call.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call, Response<Post> response) {
                if(!response.isSuccessful()){
                    return;
                }
            }

            @Override
            public void onFailure(Call<Post> call, Throwable t) {
                t1.setText(t.getMessage());
            }
        });
    }
}
