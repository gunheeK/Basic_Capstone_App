package com.peachjelly99.tuto1;

import com.google.gson.annotations.SerializedName;

public class Get {
    private String 작물;
    private String 심은날짜;
    private String 갱신시각;



    public String getName() {
        return 작물;
    }

    public String getDate() {
        return 심은날짜;
    }

    public String getUpdate() {
        return 갱신시각;
    }
}
